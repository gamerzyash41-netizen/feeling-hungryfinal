package com.duorise.feelinghungry;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_BT_CONNECT = 4101;
    private static final int REQ_BT_ENABLE = 4102;
    private WebView webView;
    private BluetoothSppBridge bridge;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        bridge = new BluetoothSppBridge(this);
        webView.addJavascriptInterface(bridge, "AndroidPrinter");
        webView.loadUrl("file:///android_asset/index.html");
        requestBtPermissionIfNeeded();
    }

    private void requestBtPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_CONNECT);
        }
    }

    @JavascriptInterface public void requestBluetoothEnable() {
        runOnUiThread(() -> {
            try {
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(intent, REQ_BT_ENABLE);
            } catch (Exception e) {
                Toast.makeText(this, "Turn Bluetooth on in Android Settings, then retry.", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT && (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "Bluetooth permission is required to connect the POS58 printer.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onDestroy() {
        if (bridge != null) bridge.close();
        if (webView != null) { webView.removeJavascriptInterface("AndroidPrinter"); webView.destroy(); }
        super.onDestroy();
    }
}
