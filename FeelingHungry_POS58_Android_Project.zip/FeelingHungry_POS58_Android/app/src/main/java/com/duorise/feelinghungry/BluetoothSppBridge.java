package com.duorise.feelinghungry;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

/** Minimal Bluetooth Classic RFCOMM/SPP bridge for ESC/POS thermal printers. */
public final class BluetoothSppBridge {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final MainActivity activity;
    private BluetoothSocket socket;
    private OutputStream output;
    private final Object lock = new Object();

    BluetoothSppBridge(MainActivity activity) { this.activity = activity; }

    private BluetoothAdapter adapter() { return BluetoothAdapter.getDefaultAdapter(); }
    private void requirePermission() {
        if (Build.VERSION.SDK_INT >= 31 && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            throw new IllegalStateException("Bluetooth permission not granted. Allow Nearby devices permission and retry.");
    }

    @JavascriptInterface public boolean isEnabled() {
        requirePermission(); BluetoothAdapter a = adapter(); return a != null && a.isEnabled();
    }

    @JavascriptInterface public boolean enable() {
        requirePermission(); BluetoothAdapter a = adapter();
        if (a == null) throw new IllegalStateException("This Android device has no Bluetooth adapter.");
        if (!a.isEnabled()) activity.requestBluetoothEnable();
        return true;
    }

    @JavascriptInterface public String list() {
        requirePermission(); BluetoothAdapter a = adapter();
        if (a == null) throw new IllegalStateException("This Android device has no Bluetooth adapter.");
        JSONArray result = new JSONArray();
        Set<BluetoothDevice> paired = a.getBondedDevices();
        if (paired != null) for (BluetoothDevice d : paired) {
            try { JSONObject item = new JSONObject(); item.put("name", d.getName() == null ? "Bluetooth printer" : d.getName()); item.put("address", d.getAddress()); result.put(item); }
            catch (Exception ignored) { }
        }
        return result.toString();
    }

    @JavascriptInterface public boolean connect(String address) {
        requirePermission();
        BluetoothAdapter a = adapter();
        if (a == null || !a.isEnabled()) throw new IllegalStateException("Turn Bluetooth on, then tap Pair Printer again.");
        synchronized (lock) {
            closeLocked();
            BluetoothDevice device = a.getRemoteDevice(address);
            try {
                BluetoothSocket candidate = device.createRfcommSocketToServiceRecord(SPP_UUID);
                candidate.connect();
                socket = candidate; output = candidate.getOutputStream();
                return true;
            } catch (Exception secureError) {
                closeLocked();
                try {
                    BluetoothSocket candidate = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    candidate.connect();
                    socket = candidate; output = candidate.getOutputStream();
                    return true;
                } catch (Exception insecureError) {
                    closeLocked();
                    throw new IllegalStateException("Could not connect to POS58 over Bluetooth SPP. Confirm it is paired and not connected to another device.", insecureError);
                }
            }
        }
    }

    @JavascriptInterface public boolean isConnected() {
        synchronized (lock) { return socket != null && socket.isConnected() && output != null; }
    }

    @JavascriptInterface public boolean writeBase64(String data) {
        synchronized (lock) {
            if (socket == null || !socket.isConnected() || output == null) throw new IllegalStateException("Printer is disconnected. Reconnect and retry.");
            try { byte[] bytes = Base64.decode(data, Base64.DEFAULT); output.write(bytes); output.flush(); return true; }
            catch (Exception e) { closeLocked(); throw new IllegalStateException("Printer write failed: " + e.getMessage(), e); }
        }
    }

    @JavascriptInterface public boolean disconnect() { synchronized (lock) { closeLocked(); return true; } }
    public void close() { synchronized (lock) { closeLocked(); } }
    private void closeLocked() {
        try { if (output != null) output.close(); } catch (Exception ignored) { }
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        output = null; socket = null;
    }
}
