# Feeling Hungry POS — POS58 Bluetooth SPP Android project

This is a **native Android Studio project source**, not a finished/signed APK. It packages the supplied Feeling Hungry POS HTML and adds a native Android WebView JavaScript bridge for Bluetooth Classic SPP (RFCOMM), which is the missing piece shown by the app's error.

## What is included

- `app/src/main/assets/index.html` — supplied POS HTML with a small adapter that connects the existing `window.bluetoothSerial`-style printer code to `window.AndroidPrinter`.
- `BluetoothSppBridge.java` — lists already-paired Bluetooth devices, connects using the standard SPP UUID, checks connection state, sends ESC/POS bytes and disconnects.
- `MainActivity.java` — WebView host and Android 12+ Nearby devices permission request.
- Manifest permissions for Bluetooth Classic / Android 12+ `BLUETOOTH_CONNECT`.

## Build the APK

1. Install Android Studio on a Windows, Mac or Linux computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `FeelingHungry_POS58_Android` folder.
4. Allow Android Studio to install the Android Gradle Plugin / Android SDK components it requests (compile SDK 35; JDK 17).
5. On the Android phone, pair the POS58 printer first in Android Settings → Bluetooth. Use the PIN supplied with the printer if Android asks. Keep the printer powered on.
6. In Android Studio choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Install the generated debug APK on the phone and grant **Nearby devices** permission when prompted.
8. Open Printer Settings → Pair Printer. Select the paired POS58 device. If Bluetooth was off, accept the Android prompt, turn it on, then tap Pair Printer again.
9. Tap **Print Test Receipt**.

## Important compatibility notes

- Website 2 APK Builder's published JavaScript API documentation describes share, toast, exit, dialogs and external-link actions; it does not document a custom Bluetooth SPP bridge. Therefore this cannot be added by pasting HTML into the builder alone. This project is a replacement native Android wrapper around the same POS HTML.
- The project uses the standard Bluetooth Classic SPP/RFCOMM service UUID. Some printer firmware uses a vendor-specific protocol or different pairing mode; if POS58 cannot connect, send the exact model label and Android error for adjustment.
- The project lists **already paired** devices only. Pair POS58 in Android Settings before using the in-app Pair button.
- This source is not yet compiled or tested against your physical POS58 device. Android Studio must build/sign it on your computer. Your existing Website 2 APK Builder APK and signing key are not modified.
- For a production release/update, configure the same application ID and signing key as the existing app if you need an in-place update. If the original builder's application ID/signing key are unknown, this build will install as a separate app.
- Keep your original HTML and APK backup until you confirm Firebase login, orders, KOT and receipt printing in the rebuilt app.
